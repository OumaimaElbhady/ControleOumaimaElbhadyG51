package org.example.controleace.dto;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class BookDto {
    Long id_Book;
    String titre;
    String publisher;
    Date datePublication;
    double price;
    String Resume;
}
