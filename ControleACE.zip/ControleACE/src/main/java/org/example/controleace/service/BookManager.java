package org.example.controleace.service;


import lombok.AllArgsConstructor;
import org.example.controleace.dao.entities.Book;
import org.example.controleace.dao.repositories.Bookrepository;
import org.example.controleace.dto.BookDto;
import org.example.controleace.mapper.BookMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
@AllArgsConstructor
public class BookManager implements BookService {

    private Bookrepository bookRepository;
    private BookMapper bookMapper;

    @Override
    public BookDto savebook(BookDto bookDto) {
        Book book = bookMapper.fromBookDtoToBook(bookDto);
        book = bookRepository.save(book);
        bookDto = bookMapper.fromBookToBookDto(book);
        return bookDto;

    }

    @Override
    public List<BookDto> getBookBytitre(String titre) {
        return null;
    }

    @Override
    public List<BookDto> getBookByTitre(String titre) {
        List<Book> books = bookRepository.findByTitre(titre);
        List<BookDto> bookDtos = new ArrayList<>();
        for (Book book : books) {
            bookDtos.add(bookMapper.fromBookToBookDto(book));
        }
        return bookDtos;
    }

}
