package org.example.controleace.dao.repositories;

import org.example.controleace.dao.entities.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Bookrepository extends JpaRepository<Book, Long> {
    public List<Book> findByTitre(String titre);

    public List<Book> findByTitre(String titre, double price);
}
