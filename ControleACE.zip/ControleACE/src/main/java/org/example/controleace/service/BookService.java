package org.example.controleace.service;

import org.example.controleace.dto.BookDto;

import java.util.List;

public interface BookService {
    public BookDto savebook(BookDto bookDto);

      public List<BookDto> getBookBytitre(String titre);

    List<BookDto> getBookByTitre(String titre);
}
