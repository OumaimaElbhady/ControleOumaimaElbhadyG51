package org.example.controleace.web;

import org.example.controleace.dto.BookDto;
import org.example.controleace.service.BookService;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;

import java.util.List;

public class BookGraphQLController {
    private BookService bookService ;

    @MutationMapping
    public BookDto saveBook(@Argument BookDto book){
        return bookService.savebook(book);
    }




    @QueryMapping
    public List<BookDto> getBookBytitre(@Argument String titre){
        return bookService.getBookBytitre(titre);
    }
}
