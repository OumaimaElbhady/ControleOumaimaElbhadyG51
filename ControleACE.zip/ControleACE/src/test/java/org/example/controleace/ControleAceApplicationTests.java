package org.example.controleace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleAceApplicationTests {

    @Test
    void contextLoads() {
    }

}
